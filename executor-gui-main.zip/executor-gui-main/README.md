# executor-gui
a roblox executor gui i made because im bored  
this is primarily used in [beckdeer skenner](https://github.com/jLn0n/scripts/tree/main/backdoor-executor).  

---

## Script
```lua
loadstring(game:HttpGetAsync("https://raw.githubusercontent.com/jLn0n/executor-gui/main/src/loader.lua"))()
```
